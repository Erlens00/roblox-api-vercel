
export default async function handler(req, res) {
  const { userid } = req.query;

  if (!userid) return res.status(400).json({ error: "Missing userId" });

  try {
    const response = await fetch(`https://games.roblox.com/v1/users/${userid}/games`);
    const games = await response.json();

    if (!games.data || games.data.length === 0) {
      return res.status(404).json({ error: "No games found for this user" });
    }

    const universeId = games.data[0].universeId;
    const devProducts = await fetch(
      `https://develop.roblox.com/v1/universes/${universeId}/developer-products`
    );

    const productData = await devProducts.json();
    return res.status(200).json(productData);
  } catch (err) {
    return res.status(500).json({ error: "Internal server error" });
  }
}
